
 /$$      /$$ /$$$$$$$   /$$$$$$           /$$$$$$  /$$$$$$$$ /$$   /$$
| $$  /$ | $$| $$__  $$ /$$__  $$         /$$__  $$| $$_____/| $$$ | $$
| $$ /$$$| $$| $$  \ $$| $$  \ $$        | $$  \__/| $$      | $$$$| $$
| $$/$$ $$ $$| $$$$$$$/| $$$$$$$$ /$$$$$$| $$ /$$$$| $$$$$   | $$ $$ $$
| $$$$_  $$$$| $$____/ | $$__  $$|______/| $$|_  $$| $$__/   | $$  $$$$
| $$$/ \  $$$| $$      | $$  | $$        | $$  \ $$| $$      | $$\  $$$
| $$/   \  $$| $$      | $$  | $$        |  $$$$$$/| $$$$$$$$| $$ \  $$
|__/     \__/|__/      |__/  |__/         \______/ |________/|__/  \__/
                                         
                                                                       

WPA-GEN Made By Zer0

Version: 1.1

+++++++++++++++++++++++++++++++++++++++++

USAGE:

1) Copy wpa-gen.py to a folder you wish to use it in.
2) Launch using "python wpa-gen.py" (Without quotations obviously xD).
3) WPA-GEN creates the password list in the folder that it is launched from.

+++++++++++++++++++++++++++++++++++++++++

REQUIREMENTS

Python 2.7.* or Above

+++++++++++++++++++++++++++++++++++++++++

For future updates and releases keep up to date with us at our Youtube channel below.

Our Youtube: https://www.youtube.com/channel/UCzjtcz6hVr1RLrF5fq2L6tA

Credit to Peter Varo: http://stackoverflow.com/users/2188562/peter-varo

Made: 06/11/2016

+++++++++++++++++++++++++++++++++++++++++

